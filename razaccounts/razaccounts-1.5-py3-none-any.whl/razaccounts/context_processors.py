from django.conf import settings


def razaccounts(request):
    return {
        "BASE_TEMPLATE": settings.BASE_TEMPLATE,
    }
