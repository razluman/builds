from typing import Any
from django.contrib.auth.models import User
from django.core.management.base import CommandParser
from django_tqdm import BaseCommand


class Command(BaseCommand):
    def add_arguments(self, parser: CommandParser) -> None:
        parser.add_argument("password")


    def handle(self, *args: Any, **options: Any) -> str | None:
        password = options["password"]
        User.objects.create_superuser("manarivo", password=password)
        User.objects.create_user("lambda", password=password)
        self.info(self.style.SUCCESS("Users created"))