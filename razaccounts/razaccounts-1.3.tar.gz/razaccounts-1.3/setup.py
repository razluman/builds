from setuptools import setup

setup()

# python -m pip install --user django-polls/dist/django-polls-0.1.tar.gz
