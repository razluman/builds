from django.apps import AppConfig


class PgiCurrenciesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pgi_currencies'
