from django.urls import path, include
from rest_framework import routers
from .views import (
    CurrencyViewSet,
    RateViewSet,
    RateAdminViewSet,
    CurrencyTables2View,
    RateTables2View,
    toggle_currency_display,
    # rate_exchange,
)

router = routers.SimpleRouter()
router.register("currency", CurrencyViewSet, basename="currency")
router.register("rate", RateViewSet, basename="rate")
router.register("admin/rate", RateAdminViewSet, basename="admin-rate")

app_name = "pgi_currencies"
urlpatterns = [
    path("api/", include(router.urls)),
    path("devises/", CurrencyTables2View.as_view(), name="currency-list2"),
    path("cours/", RateTables2View.as_view(), name="rate-list2"),
    path(
        "toggle-currency-display/<str:currency>/",
        toggle_currency_display,
        name="toggle-currency-display",
    ),
]
