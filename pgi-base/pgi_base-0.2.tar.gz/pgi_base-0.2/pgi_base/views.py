from abc import ABC
from typing import Any, Dict, List
from django_tables2.views import SingleTableMixin
from django_filters.views import FilterView


class Tables2View(ABC, SingleTableMixin, FilterView):
    def get_template_names(self) -> List[str]:
        if self.request.htmx:
            return "pgi_base/tables2_htmx.html"
        return super().get_template_names()

    def get_context_data(self, **kwargs: Any) -> Dict[str, Any]:
        context = super().get_context_data(**kwargs)
        context["hx_target"] = f"{self.model.__name__}-table"
        return context
