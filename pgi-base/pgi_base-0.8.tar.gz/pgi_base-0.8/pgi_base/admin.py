from typing import Any
from django.contrib import admin
from import_export.resources import ModelResource


class ByAtModelAdmin(admin.ModelAdmin):
    exclude = ["created_by", "updated_by"]

    def save_model(self, request: Any, obj: Any, form: Any, change: Any) -> None:
        user = request.user.username
        obj.updated_by = user
        if not change:
            obj.created_by = user
        return super().save_model(request, obj, form, change)

    class ByAtModelResource(ModelResource):
        def before_import_row(self, row, row_number=None, **kwargs):
            row["created_by"] = kwargs["user"].username
            row["updated_by"] = kwargs["user"].username
            return super().before_import_row(row, row_number, **kwargs)
