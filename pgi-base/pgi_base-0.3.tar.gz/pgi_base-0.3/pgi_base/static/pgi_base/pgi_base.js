window.addEventListener("load", () => {
    document.querySelectorAll(".nav-link").forEach(navbar => {
        if (navbar.href === window.location.href) {
            navbar.classList.add("active");
            navbar.setAttribute("aria-current", "page");
        }
    });
});

function amountFormatOnBlur(id) {
    input = document.querySelector(id);
    amount = input.value;
    amount = stringToFloat(amount);
    amount = floatToString(amount);
    if (amount == "0,00") amount = "";
    input.value = amount;
}

function stringToFloat(amount) {
    amount = amount.replace(/[^\d,.-]/g, '');
    amount = amount.replace(",", ".");
    amount = amount * 1;
    return amount;
}

function floatToString(amount) {
    amount = amount.toFixed(2)
    amount = amount.toString().replace(".", ",");
    amount = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    return amount;
}
