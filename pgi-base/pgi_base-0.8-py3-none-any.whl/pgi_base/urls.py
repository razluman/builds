from django.urls import path

app_name = "pgi_base"
urlpatterns = []
