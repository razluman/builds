from abc import ABC
from typing import Any, Dict, List
from django_tables2.views import SingleTableMixin
from django_filters.views import FilterView


class Tables2View(ABC, SingleTableMixin, FilterView):
    def get_template_names(self) -> List[str]:
        if self.request.htmx:
            return "razcore/bulma_tables2.html"
        return super().get_template_names()

    def get_context_data(self, **kwargs: Any) -> Dict[str, Any]:
        context = super().get_context_data(**kwargs)
        context["is_bordered"] = True
        context["is_striped"] = True
        context["is_narrow"] = False
        context["is_hoverable"] = True
        context["is_fullwidth"] = True
        context["table_size_mobile"] = False
        context["pagination_size_mobile"] = True
        context["pagination_alignment"] = "is-centered"
        context["hx_target"] = f"{self.model.__name__}-table"
        return context
