function stringToFloat(amount) {
    amount = amount.replace(/[^\d,.-]/g, '');
    amount = amount.replace(",", ".");
    amount = amount * 1;
    return amount;
}

function floatToString(amount, decimal = 2) {
    amount = amount.toFixed(decimal)
    amount = amount.toString().replace(".", ",");
    amount = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    return amount;
}

function formatOnBlur(id) {
    input = document.querySelector(id);
    amount = input.value;
    amount = stringToFloat(amount);
    amount = floatToString(amount);
    if (amount == "0,00") amount = "";
    input.value = amount;
}