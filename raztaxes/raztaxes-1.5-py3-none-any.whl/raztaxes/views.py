from typing import Any
import requests
from django.db.models import Q
from django.contrib import messages
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.contrib.auth.decorators import permission_required
from django.db.models.query import QuerySet
from django.shortcuts import render
from django.utils.html import format_html
from django.utils.translation import gettext as _
import django_tables2 as tables
from razcore.views import Tables2View
from .models import TaxIdentificationNumber


class TaxIdentificationNumberTable(tables.Table):
    tin = tables.Column(attrs={"td": {"class": "text-center"}})
    tax_center = tables.Column(
        attrs={
            "th": {"class": "d-none d-lg-table-cell"},
            "td": {"class": "d-none d-lg-table-cell"},
        }
    )
    taxes = tables.Column(
        attrs={
            "th": {"class": "d-none d-lg-table-cell"},
            "td": {"class": "d-none d-lg-table-cell"},
        }
    )

    class Meta:
        model = TaxIdentificationNumber
        fields = ["tin", "company_name", "trade_name", "tax_center", "taxes"]


class TaxIdentificationNumberView(PermissionRequiredMixin, Tables2View):
    model = TaxIdentificationNumber
    table_class = TaxIdentificationNumberTable
    paginate_by = 20
    permission_required = ["raztaxes.view_taxidentificationnumber"]

    def get_queryset(self) -> QuerySet[Any]:
        if self.request.htmx:
            search = self.request.GET.get("tin_search")
            if search:
                return TaxIdentificationNumber.objects.filter(
                    Q(tin__icontains=search)
                    | Q(company_name__icontains=search)
                    | Q(trade_name__icontains=search)
                    | Q(tax_center__icontains=search)
                ).order_by("tin")
        return TaxIdentificationNumber.objects.all().order_by("tin")


@permission_required("raztaxes.add_taxidentificationnumber")
def tin_import(request):
    session_key = "tin_attempts"
    if request.htmx and request.method == "POST":
        attempts = request.session.get(session_key, {})
        current_page = request.POST["tin_current_page"]
        attempt = attempts.get(current_page, 0) + 1
        data_ok = "failed"
        if attempt > 5:
            msg = _("No data found after 5 attempts")
            messages.error(request, msg)
            context = {"data_ok": data_ok}
            return render(request, "raztaxes/tin_import_result.html", context)
        request.session[session_key][current_page] = attempt
        created_obj = 0
        updated_obj = 0
        content = requests.post(
            f"http://www.impots.mg/repertoire/liste-actif-{current_page}"
        )
        data = content.json()["data"]
        data_ok = "attempt"
        if data:
            for d in data:
                tin = d["NIF"]
                company_name = set_blank_if_none(d["RAISON_SOCIALE"])
                trade_name = set_blank_if_none(d["NOM_COMMERCIAL"])
                tax_center = set_blank_if_none(d["CENTRE"])
                taxes = set_blank_if_none(d["IMPOTS"])
                created_by = request.user.username
                updated_by = request.user.username
                obj, created = TaxIdentificationNumber.objects.get_or_create(
                    tin=tin,
                    defaults={
                        "company_name": company_name,
                        "trade_name": trade_name,
                        "tax_center": tax_center,
                        "taxes": taxes,
                        "created_by": created_by,
                        "updated_by": updated_by,
                    },
                )
                if created:
                    created_obj += 1
                else:
                    if (
                        obj.company_name != company_name
                        or obj.trade_name != trade_name
                        or obj.tax_center != tax_center
                        or obj.taxes != taxes
                    ):
                        obj.company_name = company_name
                        obj.trade_name = trade_name
                        obj.tax_center = tax_center
                        obj.taxes = taxes
                        obj.updated_by = request.user.username
                        obj.save()
                        updated_obj += 1
            data_ok = "ok"
            str_page = _("Page")
            str_created = _("Created objects")
            str_updated = _("Updated objects")
            request.session["total_created"] += created_obj
            request.session["total_updated"] == updated_obj
            msg = f"""
            {str_page} {current_page}<br>
            {str_created} : {created_obj}<br>
            {str_updated} : {updated_obj}
            """
            messages.success(request, format_html(msg))
        else:
            str_page = _("Page")
            new_attempt = _("New attempt")
            msg = f"""
            {str_page} {current_page}<br>
            {new_attempt} : {attempt+1}
            """
            messages.warning(request, format_html(msg))
        total_created = _("Created total")
        total_updated = _("Updated total")
        msg = f"""
        {total_created} : {request.session.get("total_created")}<br>
        {total_updated} : {request.session.get("total_updated")}
        """
        messages.info(request, format_html(msg))
        context = {"data_ok": data_ok}
        return render(request, "raztaxes/tin_import_result.html", context)
    else:
        request.session[session_key] = {}
        request.session["total_created"] = 0
        request.session["total_updated"] = 0
        return render(request, "raztaxes/tin_import.html")


def set_blank_if_none(item):
    if item is None:
        return ""
    return item
