from django.db.models import Q
import django_tables2 as tables
from django_filters import FilterSet, CharFilter
from .models import TaxIdentificationNumber


class TaxIdentificationNumberTable(tables.Table):
    tin = tables.Column(attrs={"td": {"class": "has-text-centered"}})
    trade_name = tables.Column(
        attrs={"th": {"class": "is-hidden-mobile"}, "td": {"class": "is-hidden-mobile"}}
    )
    tax_center = tables.Column(
        attrs={"th": {"class": "is-hidden-mobile"}, "td": {"class": "is-hidden-mobile"}}
    )
    taxes = tables.Column(
        attrs={"th": {"class": "is-hidden-mobile"}, "td": {"class": "is-hidden-mobile"}}
    )

    class Meta:
        model = TaxIdentificationNumber
        fields = ["tin", "company_name", "trade_name", "tax_center", "taxes"]


class TaxIdentificationNumberFilter(FilterSet):
    search = CharFilter(method="search_filter", label="Search")

    def search_filter(self, queryset, name, value):
        return queryset.filter(
            Q(tin__icontains=value)
            | Q(company_name__icontains=value)
            | Q(trade_name__icontains=value)
            | Q(tax_center__icontains=value)
        )

    class Meta:
        model = TaxIdentificationNumber
        fields = ["search"]
