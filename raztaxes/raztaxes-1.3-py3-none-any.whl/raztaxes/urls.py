from django.urls import path
from .views import tin_import

app_name = "raztaxes"
urlpatterns = [
    path("import/", tin_import, name="tin-import"),
]
