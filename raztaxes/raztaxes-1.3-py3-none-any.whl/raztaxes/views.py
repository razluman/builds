from typing import Any
import requests
from django.contrib import messages
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.db.models.query import QuerySet
from django.shortcuts import render
from django.utils.html import format_html
from django.utils.translation import gettext as _
from razcore.views import Tables2View
from .models import TaxIdentificationNumber
from .tables import TaxIdentificationNumberTable, TaxIdentificationNumberFilter


class TaxIdentificationNumberView(PermissionRequiredMixin, Tables2View):
    model = TaxIdentificationNumber
    table_class = TaxIdentificationNumberTable
    filterset_class = TaxIdentificationNumberFilter
    paginate_by = 20
    permission_required = ["raztaxes.view_taxidentificationnumber"]

    def get_queryset(self) -> QuerySet[Any]:
        return TaxIdentificationNumber.objects.all().order_by("tin")


def tin_import(request):
    if request.htmx and request.method == "POST":
        current_page = int(request.POST["current_page"])
        created_obj = 0
        updated_obj = 0
        content = requests.post(
            f"http://www.impots.mg/repertoire/liste-actif-{current_page}"
        )
        data = content.json()["data"]
        data_ok = ""
        if data:
            for d in data:
                tin = d["NIF"]
                company_name = set_blank_if_none(d["RAISON_SOCIALE"])
                trade_name = set_blank_if_none(d["NOM_COMMERCIAL"])
                tax_center = set_blank_if_none(d["CENTRE"])
                taxes = set_blank_if_none(d["IMPOTS"])
                created_by = request.user.username
                updated_by = request.user.username
                obj, created = TaxIdentificationNumber.objects.get_or_create(
                    tin=tin,
                    defaults={
                        "company_name": company_name,
                        "trade_name": trade_name,
                        "tax_center": tax_center,
                        "taxes": taxes,
                        "created_by": created_by,
                        "updated_by": updated_by,
                    },
                )
                if created:
                    created_obj += 1
                else:
                    if (
                        obj.company_name != company_name
                        or obj.trade_name != trade_name
                        or obj.tax_center != tax_center
                        or obj.taxes != taxes
                    ):
                        obj.company_name = company_name
                        obj.trade_name = trade_name
                        obj.tax_center = tax_center
                        obj.taxes = taxes
                        obj.updated_by = request.user.username
                        obj.save()
                        updated_obj += 1
            data_ok = "ok"
            str_page = _("Page")
            str_created = _("Created objects")
            str_updated = _("Updated objects")
            msg = f"""
            {str_page} {current_page}<br>
            {str_created} : {created_obj}<br>
            {str_updated} : {updated_obj}
            """
            messages.success(request, format_html(msg))
        else:
            msg = _("No data found")
            messages.error(request, format_html(msg))
        context = {
            "data_ok": data_ok,
        }
        return render(request, "raztaxes/tin_import_result.html", context)
    else:
        return render(request, "raztaxes/tin_import.html")


def set_blank_if_none(item):
    if item is None:
        return ""
    return item
