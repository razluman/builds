from typing import Any
import requests
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.db.models.query import QuerySet
from django.shortcuts import render, redirect
from django.views import View
from django.views.generic.edit import FormView
from django.views.decorators.http import require_POST
from razcore.views import Tables2View
from .models import TaxIdentificationNumber
from .tables import TaxIdentificationNumberTable, TaxIdentificationNumberFilter
from .forms import TinImportForm


class TaxIdentificationNumberView(PermissionRequiredMixin, Tables2View):
    model = TaxIdentificationNumber
    table_class = TaxIdentificationNumberTable
    filterset_class = TaxIdentificationNumberFilter
    paginate_by = 50
    permission_required = ["raztaxes.view_taxidentificationnumber"]

    def get_queryset(self) -> QuerySet[Any]:
        return TaxIdentificationNumber.objects.all().order_by("tin")


class TinImportView(PermissionRequiredMixin, FormView):
    template_name = "raztaxes/tin_import.html"
    form_class = TinImportForm
    permission_required = ["raztaxes.add_taxidentificationnumber"]

    def get_initial(self):
        initial = super().get_initial()
        initial.update({"start_page": 1})
        initial.update({"end_page": 2})
        return initial

    def form_valid(self, form: Any):
        start_page = int(self.request.POST["start_page"])
        end_page = int(self.request.POST["end_page"])
        created_obj = 0
        updated_obj = 0
        processed_pages = 0
        for page in range(start_page, end_page + 1):
            content = requests.post(
                f"http://www.impots.mg/repertoire/liste-actif-{page}"
            )
            data = content.json()["data"]
            if data:
                for d in data:
                    tin = d["NIF"]
                    company_name = set_blank_if_none(d["RAISON_SOCIALE"])
                    trade_name = set_blank_if_none(d["NOM_COMMERCIAL"])
                    tax_center = set_blank_if_none(d["CENTRE"])
                    taxes = set_blank_if_none(d["IMPOTS"])
                    created_by = self.request.user.username
                    updated_by = self.request.user.username
                    obj, created = TaxIdentificationNumber.objects.get_or_create(
                        tin=tin,
                        defaults={
                            "company_name": company_name,
                            "trade_name": trade_name,
                            "tax_center": tax_center,
                            "taxes": taxes,
                            "created_by": created_by,
                            "updated_by": updated_by,
                        },
                    )
                    if created:
                        created_obj += 1
                    else:
                        if (
                            obj.company_name != company_name
                            or obj.trade_name != trade_name
                            or obj.tax_center != tax_center
                            or obj.taxes != taxes
                        ):
                            obj.company_name = company_name
                            obj.trade_name = trade_name
                            obj.tax_center = tax_center
                            obj.taxes = taxes
                            obj.updated_by = self.request.user.username
                            obj.save()
                            updated_obj += 1
                processed_pages += 1
        return redirect(
            "raztaxes:tin-import-result",
            created=created_obj,
            updated=updated_obj,
            processed=processed_pages,
        )


class TinImportResultView(View):
    template_name = "raztaxes/tin_import_result.html"

    def get(self, request, created, updated, processed):
        context = {
            "created_obj": created,
            "updated_obj": updated,
            "processed_pages": processed,
        }
        return render(request, self.template_name, context)


def set_blank_if_none(item):
    if item is None:
        return ""
    return item


@require_POST
def import_taxpayers(request):
    # if not request.user.is_superuser:
    # return HttpResponseRedirect(reverse("index"))
    created_obj = 0
    updated_obj = 0
    page = 1
    while True:
        content = requests.post(f"http://www.impots.mg/repertoire/liste-actif-{page}")
        data = content.json()["data"]
        if data:
            for d in data:
                tin = d["NIF"]
                company_name = set_blank_if_none(d["RAISON_SOCIALE"])
                trade_name = set_blank_if_none(d["NOM_COMMERCIAL"])
                tax_center = set_blank_if_none(d["CENTRE"])
                taxes = set_blank_if_none(d["IMPOTS"])
                created_by = request.user.username
                updated_by = request.user.username
                obj, created = TaxIdentificationNumber.objects.get_or_create(
                    tin=tin,
                    defaults={
                        "company_name": company_name,
                        "trade_name": trade_name,
                        "tax_center": tax_center,
                        "taxes": taxes,
                        "created_by": created_by,
                        "updated_by": updated_by,
                    },
                )
                if created:
                    created_obj += 1
                else:
                    if (
                        obj.company_name != company_name
                        or obj.trade_name != trade_name
                        or obj.tax_center != tax_center
                        or obj.taxes != taxes
                    ):
                        obj.company_name = company_name
                        obj.trade_name = trade_name
                        obj.tax_center = tax_center
                        obj.taxes = taxes
                        obj.updated_by = request.user.username
                        obj.save()
                        updated_obj += 1
            page += 1
        else:
            break
    return render(
        request,
        "raztaxes/taxpayers_import.html",
        {
            "created_obj": created_obj,
            "updated_obj": updated_obj,
            "last_page_success": page - 1,
        },
    )
