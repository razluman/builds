from django.urls import path
from .views import TinImportView, TinImportResultView

app_name = "raztaxes"
urlpatterns = [
    path("import/", TinImportView.as_view(), name="tin-import"),
    path(
        "import/result/<int:created>/<int:updated>/<int:processed>/",
        TinImportResultView.as_view(),
        name="tin-import-result",
    ),
]
