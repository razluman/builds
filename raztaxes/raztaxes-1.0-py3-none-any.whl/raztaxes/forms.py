from django import forms
from django.utils.translation import gettext as _


class TinImportForm(forms.Form):
    start_page = forms.IntegerField(
        label=_("Start page"),
        widget=forms.NumberInput(
            attrs={"class": "has-text-centered", "style": "width:100px"}
        ),
    )
    end_page = forms.IntegerField(
        label=_("End page"),
        widget=forms.NumberInput(
            attrs={"class": "has-text-centered", "style": "width:100px"}
        ),
    )
