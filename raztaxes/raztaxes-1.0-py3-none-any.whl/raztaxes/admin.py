from typing import Any
from django.contrib import admin
from import_export.admin import ImportExportMixin
from import_export.resources import ModelResource
from .models import TaxIdentificationNumber


class CreatedUpdatedModelAdmin(ImportExportMixin, admin.ModelAdmin):
    exclude = ["created_by", "updated_by"]

    def save_model(self, request: Any, obj: Any, form: Any, change: Any) -> None:
        user = request.user.username
        obj.updated_by = user
        if not change:
            obj.created_by = user
        return super().save_model(request, obj, form, change)


@admin.register(TaxIdentificationNumber)
class TaxIdentificationNumberAdmin(CreatedUpdatedModelAdmin):
    list_display = ["tin", "company_name", "trade_name", "tax_center", "taxes"]
    ordering = ["tin"]
    search_fields = ["tin", "company_name", "trade_name"]

    class TaxIdentificationNumberResource(ModelResource):
        def before_import_row(self, row, row_number=None, **kwargs):
            if row["trade_name"] is None:
                row["trade_name"] = ""
            row["created_by"] = kwargs["user"].username
            row["updated_by"] = kwargs["user"].username
            return super().before_import_row(row, row_number, **kwargs)

        class Meta:
            model = TaxIdentificationNumber
            skip_unchanged = True
            report_skipped = True

    resource_class = TaxIdentificationNumberResource
