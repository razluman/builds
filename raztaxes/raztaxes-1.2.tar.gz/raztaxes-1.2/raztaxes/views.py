from typing import Any
import requests
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.db.models.query import QuerySet
from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic.edit import FormView
from razcore.views import Tables2View
from .models import TaxIdentificationNumber
from .tables import TaxIdentificationNumberTable, TaxIdentificationNumberFilter
from .forms import TinImportForm


class TaxIdentificationNumberView(PermissionRequiredMixin, Tables2View):
    model = TaxIdentificationNumber
    table_class = TaxIdentificationNumberTable
    filterset_class = TaxIdentificationNumberFilter
    paginate_by = 20
    permission_required = ["raztaxes.view_taxidentificationnumber"]

    def get_queryset(self) -> QuerySet[Any]:
        return TaxIdentificationNumber.objects.all().order_by("tin")


class TinImportView(PermissionRequiredMixin, FormView):
    template_name = "raztaxes/tin_import.html"
    form_class = TinImportForm
    permission_required = ["raztaxes.add_taxidentificationnumber"]
    success_url = reverse_lazy("index")

    def get_initial(self):
        initial = super().get_initial()
        initial.update({"start_page": 1})
        initial.update({"end_page": 2})
        return initial

    def form_valid(self, form: Any):
        if self.request.htmx:
            start_page = int(self.request.POST["start_page"])
            end_page = int(self.request.POST["end_page"])
            created_obj = 0
            updated_obj = 0
            processed_pages = 0
            for page in range(start_page, end_page + 1):
                content = requests.post(
                    f"http://www.impots.mg/repertoire/liste-actif-{page}"
                )
                data = content.json()["data"]
                if data:
                    for d in data:
                        tin = d["NIF"]
                        company_name = set_blank_if_none(d["RAISON_SOCIALE"])
                        trade_name = set_blank_if_none(d["NOM_COMMERCIAL"])
                        tax_center = set_blank_if_none(d["CENTRE"])
                        taxes = set_blank_if_none(d["IMPOTS"])
                        created_by = self.request.user.username
                        updated_by = self.request.user.username
                        obj, created = TaxIdentificationNumber.objects.get_or_create(
                            tin=tin,
                            defaults={
                                "company_name": company_name,
                                "trade_name": trade_name,
                                "tax_center": tax_center,
                                "taxes": taxes,
                                "created_by": created_by,
                                "updated_by": updated_by,
                            },
                        )
                        if created:
                            created_obj += 1
                        else:
                            if (
                                obj.company_name != company_name
                                or obj.trade_name != trade_name
                                or obj.tax_center != tax_center
                                or obj.taxes != taxes
                            ):
                                obj.company_name = company_name
                                obj.trade_name = trade_name
                                obj.tax_center = tax_center
                                obj.taxes = taxes
                                obj.updated_by = self.request.user.username
                                obj.save()
                                updated_obj += 1
                    processed_pages += 1
            context = {
                "start_page": start_page,
                "end_page": end_page,
                "created_obj": created_obj,
                "updated_obj": updated_obj,
                "processed_pages": processed_pages,
            }
            return render(self.request, "raztaxes/tin_import_result.html", context)
        return super().form_valid(form)


def set_blank_if_none(item):
    if item is None:
        return ""
    return item
