from django.db import models
from django.utils import translation
from django.utils.translation import gettext_lazy as _


class TaxIdentificationNumber(models.Model):
    tin = models.CharField(_("TIN"), max_length=10, unique=True)
    company_name = models.CharField(_("company name"), max_length=250, blank=True)
    trade_name = models.CharField(_("trade name"), max_length=250, blank=True)
    tax_center = models.CharField(_("tax center"), max_length=50, blank=True)
    taxes = models.CharField(_("taxes"), max_length=150, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.CharField(max_length=150)
    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.CharField(max_length=150)

    def __str__(self) -> str:
        return f"{self.tin} {self.company_name}"

    class Meta:
        verbose_name = _("tax identification number")
        verbose_name_plural = _("tax identification numbers")


def taxes_translated(language):
    with translation.override(language):
        return translation.gettext("Taxes")


def tins_list_translated(language):
    with translation.override(language):
        return translation.gettext("TIN's List")
