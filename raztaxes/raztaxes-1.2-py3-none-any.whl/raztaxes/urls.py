from django.urls import path
from .views import TinImportView

app_name = "raztaxes"
urlpatterns = [
    path("import/", TinImportView.as_view(), name="tin-import"),
]
