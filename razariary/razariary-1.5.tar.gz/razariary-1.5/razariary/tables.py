from django.utils.translation import gettext as _
import django_tables2 as tables
from .models import Currency, Rate


class CurrencyTable(tables.Table):
    currency = tables.Column(
        verbose_name=_("Cur"), attrs={"td": {"class": "text-center"}}
    )

    class Meta:
        model = Currency
        fields = ["currency", "name", "propagation"]
        row_attrs = {
            "onClick": 'curRowClick(this.querySelector("td").firstChild.nodeValue);',
        }


class RateTable(tables.Table):
    date = tables.Column(attrs={"td": {"class": "text-center c-date"}})
    rate = tables.Column(attrs={"td": {"class": "text-end c-rate"}})

    def render_date(self, value):
        return value.strftime("%d/%m/%y")

    def render_rate(self, value):
        return f"{value:,.2f}".replace(",", " ").replace(".", ",")

    class Meta:
        model = Rate
        fields = ["date", "rate"]
        row_attrs = {
            "onClick": 'rateRowClick(this.querySelector(".c-date").firstChild.nodeValue, this.querySelector(".c-rate").firstChild.nodeValue);',
        }
