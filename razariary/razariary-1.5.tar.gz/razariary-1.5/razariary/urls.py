from django.urls import path
from .views import get_datalist, CurrencyView, RateView

app_name = "razariary"
urlpatterns = [
    path("curdatalist/", get_datalist, name="cur-datalist"),
    path("curlist/", CurrencyView.as_view(), name="cur-list"),
    path("ratelist/", RateView.as_view(), name="rate-list"),
]
