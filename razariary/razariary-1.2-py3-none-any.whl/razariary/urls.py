from django.urls import path
from .views import toggle_currency_display

app_name = "razariary"
urlpatterns = [
    path(
        "toggle-currency-display/<str:currency>/",
        toggle_currency_display,
        name="toggle-currency-display",
    ),
]
