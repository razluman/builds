from rest_framework import serializers
from .models import Rate


class RateSerializer(serializers.ModelSerializer):
    name = serializers.ReadOnlyField(source="currency.name")

    class Meta:
        model = Rate
        fields = ["id", "date", "currency", "name", "rate"]
