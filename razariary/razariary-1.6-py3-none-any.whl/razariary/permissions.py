from rest_framework import permissions


class IsRateAuthorized(permissions.BasePermission):
    def has_permission(self, request, view):
        method = request.method
        if method in permissions.SAFE_METHODS:
            return True
        if not bool(request.user and request.user.is_authenticated):
            return False
        if method == "POST": 
            if request.user.has_perm("razariary.add_rate"):
                return True
        if method in ["PUT","PATCH"]:
            if request.user.has_perm("razariary.change_rate"):
                return True
        if method == "DELETE": 
            if request.user.has_perm("razariary.delete_rate"):
                return True
        return False