from django.urls import reverse
from django.db.models import Q
from django.utils.html import format_html
from django.utils.translation import gettext as _
import django_tables2 as tables
from django_filters import FilterSet, CharFilter, ChoiceFilter, NumberFilter
from .models import Currency, Rate


class CurrencyTable(tables.Table):
    currency = tables.Column(
        verbose_name=_("Cur"), attrs={"td": {"class": "has-text-centered"}}
    )
    propagation = tables.Column(
        attrs={
            "th": {"class": "is-hidden-mobile"},
            "td": {"class": "is-hidden-mobile"},
        }
    )
    display = tables.Column(
        empty_values=(),
        orderable=False,
        verbose_name=_("Display"),
        attrs={"td": {"class": "has-text-centered"}},
    )

    class Meta:
        model = Currency
        fields = ["currency", "name", "propagation", "display"]

    def render_display(self, record):
        if record.currency in self.request.session.get("mycurrencies", []):
            checked = "checked=" "checked" ""
        else:
            checked = ""
        div = f"""
        <div id="switch{record.currency}divinput">
            <label for="switch{record.currency}" class="checkbox">
                <input id="switch{record.currency}"
                        type="checkbox"
                        class="form-check-input"
                        hx-post="{reverse("razariary:toggle-currency-display", args=[record.currency])}"
                        hx-target="#none"
                        {checked}>
            </label>
        </div>
        <div id="switch{record.currency}divspinner" class="is-hidden">
            <i class="fas fa-spinner fa-spin form-check-input"></i>
        </div>
        """
        return format_html(div)


class CurrencyFilter(FilterSet):
    search = CharFilter(method="search_filter", label="Search")
    display = ChoiceFilter(
        method="display_filter",
        choices=(
            (1, "All"),
            (2, "Displayed"),
            (3, "Hidden"),
        ),
    )

    class Meta:
        model = Currency
        fields = ["search", "display"]

    def search_filter(self, queryset, name, value):
        return queryset.filter(
            Q(currency__icontains=value)
            | Q(name__icontains=value)
            | Q(propagation__icontains=value)
        )

    def display_filter(self, queryset, name, value):
        mycurrencies = self.request.session.get("mycurrencies")
        if not mycurrencies:
            active_currencies = Currency.objects.filter(active=True)
            mycurrencies = [currency.currency for currency in active_currencies]
            self.request.session["mycurrencies"] = mycurrencies
        if value == "2":
            queryset = queryset.filter(currency__in=mycurrencies)
        if value == "3":
            queryset = queryset.exclude(currency__in=mycurrencies)
        return queryset


class RateTable(tables.Table):
    currency = tables.Column(
        verbose_name=_("Cur"), attrs={"td": {"class": "has-text-centered"}}
    )
    date = tables.Column(attrs={"td": {"class": "has-text-centered"}})

    class Meta:
        model = Rate
        fields = ["currency", "date", "rate"]

    def render_date(self, value):
        return value.strftime("%d/%m/%y")

    def render_rate(self, value, record):
        rate = f"{value:,.2f}".replace(",", " ").replace(".", ",")
        div = f"""
        <div class="has-text-right">
            <span id="span{record.id}" aria-hidden="true">{rate}</span>
            <a class="has-text-primary" onclick='clickCalc("{record.date.strftime("%d/%m/%Y")}", "{record.currency}", "{rate}")'>
                <i class="fa-solid fa-calculator is-pulled-right ml-3"></i>
            </a>
        </div>
        """
        return format_html(div)


class RateFilter(FilterSet):
    currency = CharFilter(field_name="currency__currency", lookup_expr="icontains")
    year = NumberFilter(field_name="date__year", lookup_expr="exact")
    month = NumberFilter(field_name="date__month", lookup_expr="exact")

    class Meta:
        model = Rate
        fields = ["currency", "year", "month"]
