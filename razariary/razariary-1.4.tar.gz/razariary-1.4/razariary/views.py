from typing import Any, Dict, List
from datetime import datetime
from django.db.models.query import QuerySet
from django.views import View
from django.shortcuts import render
from django.core.paginator import Paginator
from razcore.views import Tables2View
from .models import Currency, Rate
from .tables import CurrencyTable, CurrencyFilter, RateTable


class CurrencyView(Tables2View):
    model = Currency
    table_class = CurrencyTable
    filterset_class = CurrencyFilter
    paginate_by = 10

    def get_queryset(self) -> QuerySet[Any]:
        object_list = Currency.objects.all().order_by("currency")
        return object_list


class RateView(Tables2View):
    model = Rate
    table_class = RateTable
    paginate_by = 5

    def get_template_names(self) -> List[str]:
        if self.request.htmx:
            return "razariary/rate_tables2.html"
        return super().get_template_names()

    def get_table_data(self):
        if not self.request.session.get("current_currency"):
            self.request.session["current_currency"] = "EUR"
        date_format = "%Y-%m-%d"
        if self.request.htmx:
            self.request.session["current_currency"] = self.request.GET.get(
                "current_currency"
            )
            self.request.session["start_date"] = self.request.GET.get("start_date")
            self.request.session["end_date"] = self.request.GET.get("end_date")
        qs = {}
        current_currency = self.request.session.get("current_currency")
        start_date = self.request.session.get("start_date")
        end_date = self.request.session.get("end_date")
        if current_currency:
            qs = Rate.objects.filter(
                currency__currency__iexact=current_currency
            ).order_by("-date")
            try:
                if start_date:
                    start_date = datetime.strptime(start_date, date_format).date()
                    qs = qs.filter(date__gte=start_date)
                if end_date:
                    end_date = datetime.strptime(end_date, date_format).date()
                    qs = qs.filter(date__lte=end_date)
            except ValueError:
                pass
        return qs


def get_datalist(request):
    datalist = None
    current_currency = request.GET.get("current_currency")
    if current_currency:
        datalist = Currency.objects.filter(
            currency__icontains=current_currency
        ).order_by("currency")[:5]
    return render(request, "razariary/datalist.html", {"datalist": datalist})
