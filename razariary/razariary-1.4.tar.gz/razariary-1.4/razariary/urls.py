from django.urls import path
from .views import get_datalist

app_name = "razariary"
urlpatterns = [
    path("curdatalist/", get_datalist, name="cur-datalist"),
]
