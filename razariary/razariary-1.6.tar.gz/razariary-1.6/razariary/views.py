from typing import Any, Dict, List
from datetime import datetime
from django.db.models import Q
from django.db.models.query import QuerySet
from django.urls import reverse
from django.shortcuts import render
from rest_framework import viewsets, filters,pagination
from razcore.views import Tables2View
from .models import Currency, Rate
from .tables import CurrencyTable, RateTable
from .serializers import RateSerializer
from .permissions import IsRateAuthorized


class CurrencyView(Tables2View):
    model = Currency
    table_class = CurrencyTable
    paginate_by = 10

    def get_queryset(self) -> QuerySet[Any]:
        if self.request.htmx:
            search = self.request.GET.get("cur_search")
            if search:
                return Currency.objects.filter(
                    Q(currency__icontains=search)
                    | Q(name__icontains=search)
                    | Q(propagation__icontains=search)
                ).order_by("currency")
        return Currency.objects.all().order_by("currency")

    def get_context_data(self, **kwargs: Any) -> Dict[str, Any]:
        context = super().get_context_data(**kwargs)
        context["hx_get"] = reverse("razariary:cur-list")
        return context


class RateView(Tables2View):
    model = Rate
    table_class = RateTable
    paginate_by = 5

    def get_template_names(self) -> List[str]:
        if self.request.htmx:
            return "razariary/rate_tables2.html"
        return super().get_template_names()

    def get_context_data(self, **kwargs: Any) -> Dict[str, Any]:
        context = super().get_context_data(**kwargs)
        context["hx_get"] = reverse("razariary:rate-list")
        return context

    def get_queryset(self) -> QuerySet[Any]:
        date_format = "%Y-%m-%d"
        qs = Rate.objects.none()
        if self.request.htmx:
            current_currency = self.request.GET.get("current_currency", "EUR")
            start_date = self.request.GET.get("start_date", "")
            end_date = self.request.GET.get("end_date", "")
            self.request.session["current_currency"] = current_currency
            self.request.session["start_date"] = start_date
            self.request.session["end_date"] = end_date
            qs = Rate.objects.filter(
                currency__currency__iexact=current_currency
            ).order_by("-date")
            try:
                if start_date:
                    start_date = datetime.strptime(start_date, date_format).date()
                    qs = qs.filter(date__gte=start_date)
                if end_date:
                    end_date = datetime.strptime(end_date, date_format).date()
                    qs = qs.filter(date__lte=end_date)
            except ValueError:
                pass
        return qs


def get_datalist(request):
    datalist = None
    current_currency = request.GET.get("current_currency")
    if current_currency:
        datalist = Currency.objects.filter(
            currency__icontains=current_currency
        ).order_by("currency")[:5]
    return render(request, "razariary/datalist.html", {"datalist": datalist})


class RateViewSet(viewsets.ModelViewSet):
    serializer_class = RateSerializer
    permission_classes = [IsRateAuthorized]

    def get_queryset(self):
        queryset = Rate.objects.all().order_by("-date", "currency")
        currency= self.request.GET.get("cur")
        if currency:
            queryset = queryset.filter(currency__currency__iexact=currency)
        year = self.request.GET.get("y")
        if year:
            queryset = queryset.filter(date__year=year)
        month = self.request.GET.get("m")
        if month:
            queryset = queryset.filter(date__month=month)
        day = self.request.GET.get("d")
        if day:
            queryset = queryset.filter(date__day=day)
        return queryset

    def perform_create(self, serializer):
        username = self.request.user.username
        serializer.save(created_by=username, updated_by=username)

    def perform_update(self, serializer):
        username = self.request.user.username
        serializer.save(updated_by=username)
