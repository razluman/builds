from typing import Any, Dict
from django.shortcuts import HttpResponse
from django.views.decorators.http import require_POST
from django.db.models.query import QuerySet
from razcore.views import Tables2View
from .models import Currency, Rate
from .tables import CurrencyTable, CurrencyFilter, RateTable, RateFilter


class CurrencyView(Tables2View):
    model = Currency
    table_class = CurrencyTable
    filterset_class = CurrencyFilter
    paginate_by = 10

    def get_queryset(self) -> QuerySet[Any]:
        object_list = Currency.objects.all().order_by("currency")
        mycurrencies = self.request.session.get("mycurrencies")
        if not mycurrencies:
            active_currencies = Currency.objects.filter(active=True)
            mycurrencies = [currency.currency for currency in active_currencies]
            self.request.session["mycurrencies"] = mycurrencies
        return object_list

    def get_context_data(self, **kwargs: Any) -> Dict[str, Any]:
        context = super().get_context_data(**kwargs)
        context["table_size_mobile"] = True
        return context


@require_POST
def toggle_currency_display(request, currency):
    currency = currency.upper()
    mycurrencies = request.session.get("mycurrencies")
    if not mycurrencies:
        active_currencies = Currency.objects.filter(active=True)
        mycurrencies = [currency.currency for currency in active_currencies]
    if currency in mycurrencies:
        mycurrencies.remove(currency)
    else:
        mycurrencies.append(currency)
    request.session["mycurrencies"] = mycurrencies
    return HttpResponse("")


class RateView(Tables2View):
    model = Rate
    table_class = RateTable
    filterset_class = RateFilter
    paginate_by = 10

    def get_queryset(self) -> QuerySet[Any]:
        mycurrencies = self.request.session.get("mycurrencies")
        if not mycurrencies:
            active_currencies = Currency.objects.filter(active=True)
            mycurrencies = [currency.currency for currency in active_currencies]
            self.request.session["mycurrencies"] = mycurrencies
        object_list = Rate.objects.filter(currency__in=mycurrencies).order_by(
            "-date", "currency"
        )
        return object_list
