from django.db.models import Q
from django.utils.translation import gettext as _
import django_tables2 as tables
from django_filters import FilterSet, CharFilter
from .models import Currency, Rate


class CurrencyTable(tables.Table):
    currency = tables.Column(
        verbose_name=_("Cur"), attrs={"td": {"class": "text-center"}}
    )

    class Meta:
        model = Currency
        fields = ["currency", "name", "propagation"]
        row_attrs = {
            "onClick": 'curRowClick(this.querySelector("td").firstChild.nodeValue);',
        }


class CurrencyFilter(FilterSet):
    search = CharFilter(method="search_filter", label="Search")

    class Meta:
        model = Currency
        fields = ["search"]

    def search_filter(self, queryset, name, value):
        return queryset.filter(
            Q(currency__icontains=value)
            | Q(name__icontains=value)
            | Q(propagation__icontains=value)
        )


class RateTable(tables.Table):
    date = tables.Column(attrs={"td": {"class": "text-center c-date"}})
    rate = tables.Column(attrs={"td": {"class": "text-end c-rate"}})

    def render_date(self, value):
        return value.strftime("%d/%m/%y")

    def render_rate(self, value):
        return f"{value:,.2f}".replace(",", " ").replace(".", ",")

    class Meta:
        model = Rate
        fields = ["date", "rate"]
        row_attrs = {
            "onClick": 'curRowClick(this.querySelector(".c-date").firstChild.nodeValue, this.querySelector(".c-rate").firstChild.nodeValue);',
        }


class RateFilter(FilterSet):
    current_currency = CharFilter(method="search_filter")

    class Meta:
        model = Rate
        fields = ["current_currency"]

    def search_filter(self, queryset, name, value):
        return None
