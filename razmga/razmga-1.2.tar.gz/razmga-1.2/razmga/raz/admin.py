from collections.abc import Sequence
from django.http.request import HttpRequest
from django.contrib import admin
from .models import UPDATER_FIELDS


class UpdaterModelAdmin(admin.ModelAdmin):
    updater_display = UPDATER_FIELDS
    my_display = []

    def get_list_display(self, request: HttpRequest) -> Sequence[str]:
        return self.my_display + self.updater_display

    def get_readonly_fields(self, request, obj=None):
        read_only = super().get_readonly_fields(request, obj)
        if obj:
            read_only += tuple(self.model.non_editable_fields)
        return read_only

    def save_model(self, request, obj, form, change) -> None:
        user = request.user.username
        obj.updated_by = user
        if not obj.created_by:
            obj.created_by = user
        return super().save_model(request, obj, form, change)

    def save_formset(self, request, form, formset, change):
        user = request.user.username
        for inline_form in formset.forms:
            if inline_form.has_changed():
                inline_form.instance.updated_by = user
                if not inline_form.instance.created_by:
                    inline_form.instance.created_by = user
        return super().save_formset(request, form, formset, change)
