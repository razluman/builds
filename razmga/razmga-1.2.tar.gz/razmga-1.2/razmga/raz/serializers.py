from rest_framework import serializers
from .models import IS_NOT_EDITABLE, UpdaterModel


class UpdaterSerializer(serializers.ModelSerializer):
    class Meta:
        abstract = True
        model = UpdaterModel

    def clean_data(self, data):
        pass

    def validate(self, data):
        user = self.context["request"].user.username
        upper_fields = self.Meta.model.upper_fields
        non_editable_fields = self.Meta.model.non_editable_fields
        data = super().validate(data)
        if user:
            if not self.instance:
                data["created_by"] = user
            else:
                data["created_by"] = self.instance.created_by
            data["updated_by"] = user
        for field in upper_fields:
            val = data[field]
            if val is not None:
                data[field] = val.upper()
        for field in non_editable_fields:
            if self.instance and getattr(self.instance, field) != data[field]:
                raise serializers.ValidationError({field: IS_NOT_EDITABLE})
        self.clean_data(data)
        return data
