from typing import Any
from django.db import models
from django.core.exceptions import ObjectDoesNotExist, ValidationError
from django.utils.translation import gettext_lazy as _
from django.core.validators import RegexValidator
from ufid import generate_user_friendly_id

IS_NOT_EDITABLE = _("This field is not editable.")
UPDATER_FIELDS = ["created_by", "created_at", "updated_by", "updated_at"]


def generate_user_friendly_id8():
    return generate_user_friendly_id(8)


class FriendlyPk(models.CharField):
    def __init__(self, *args, **kwargs):
        # remove from kwargs, because 'super().__init__()'
        # will not accept that argument
        extra_arg = kwargs.pop("extra_arg", None)

        # set some default values if they where not provided
        kwargs.setdefault("primary_key", True)
        kwargs.setdefault("editable", False)
        kwargs.setdefault("max_length", 8)
        kwargs.setdefault("validators", [RegexValidator(regex="[0-9a-zA-Z]{8}")])
        kwargs.setdefault("default", generate_user_friendly_id8)

        super().__init__(*args, **kwargs)

        # add as an instance attribute after 'super().__init__()'
        self.extra_arg = extra_arg


class UpdaterModel(models.Model):
    upper_fields = []
    non_editable_fields = []
    list_display = []
    created_by = models.CharField(max_length=150, default=None, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_by = models.CharField(max_length=150, default=None, editable=False)
    updated_at = models.DateTimeField(auto_now=True)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.init_non_editable_fields = {}
        for field in self.non_editable_fields:
            try:
                self.init_non_editable_fields["__" + field] = getattr(self, field)
            except ObjectDoesNotExist:
                self.init_non_editable_fields["__" + field] = None

    def clean(self) -> None:
        super().clean()
        for field in self.upper_fields:
            val = getattr(self, field)
            if val is not None:
                setattr(self, field, val.upper())
        for field in self.non_editable_fields:
            init_val = self.init_non_editable_fields["__" + field]
            if init_val and init_val != getattr(self, field):
                raise ValidationError({field: IS_NOT_EDITABLE})

    def full_clean_save(self):
        try:
            self.full_clean()
            self.save()
            return None
        except ValidationError as e:
            return e.message_dict

    class Meta:
        abstract = True
