from django.db import models
from django.utils.translation import gettext_lazy as _
from .raz.models import UpdaterModel


class Currency(UpdaterModel):
    upper_fields = ["currency"]
    non_editable_fields = ["currency"]
    list_display = ["currency", "name", "propagation"]
    currency = models.CharField(
        primary_key=True, max_length=3, verbose_name=_("currency")
    )
    name = models.CharField(max_length=50, verbose_name=_("name"))
    propagation = models.TextField(blank=True, verbose_name=_("propagation"))

    def __str__(self):
        return f"{self.currency}"

    class Meta:
        verbose_name = _("currency")
        verbose_name_plural = _("currencies")


class Rate(UpdaterModel):
    list_display = ["id", "date", "currency", "rate"]
    date = models.DateField(verbose_name=_("date"))
    rate = models.DecimalField(max_digits=10, decimal_places=2, verbose_name=_("rate"))
    currency = models.ForeignKey(
        Currency,
        on_delete=models.CASCADE,
        related_name="rates",
        verbose_name=_("currency"),
    )

    def __str__(self):
        return f"{self.currency} {self.date} {self.rate}"

    class Meta:
        verbose_name = _("rate")
        verbose_name_plural = _("rates")
        constraints = [
            models.UniqueConstraint(fields=["currency", "date"], name="currency_rate")
        ]
