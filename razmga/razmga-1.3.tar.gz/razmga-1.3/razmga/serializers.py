from rest_framework import serializers
from .raz.serializers import UpdaterSerializer
from .raz.models import UPDATER_FIELDS
from .models import Currency, Rate


class CurrencySerializer(UpdaterSerializer):
    url = serializers.HyperlinkedIdentityField(view_name="currency-api-detail")

    class Meta:
        model = Currency
        fields = ["url"] + model.list_display


class CurrencyRetrieveSerializer(UpdaterSerializer):
    class Meta:
        model = Currency
        fields = model.list_display + UPDATER_FIELDS


class RateSerializer(UpdaterSerializer):
    url = serializers.HyperlinkedIdentityField(view_name="rate-api-detail")
    currency_name = serializers.SerializerMethodField()

    def get_currency_name(self, obj):
        return obj.currency.name

    class Meta:
        model = Rate
        fields = ["url"] + model.list_display + ["currency_name"]


class RateRetrieveSerializer(UpdaterSerializer):
    currency_name = serializers.SerializerMethodField()

    def get_currency_name(self, obj):
        return obj.currency.name

    class Meta:
        model = Rate
        fields = model.list_display + ["currency_name"] + UPDATER_FIELDS
