from django.db.models import Q, Exists, OuterRef
from django.utils.translation import gettext_lazy as _
from django_filters import rest_framework as filters
from .models import Rate


class CurrencyFilter(filters.FilterSet):
    search = filters.CharFilter(
        method="search_filter", label=_("Search in currency or name or propagation")
    )
    is_used = filters.BooleanFilter(method="is_used_filter", label=_("Used in Rates"))

    def search_filter(self, queryset, name, value):
        return queryset.filter(
            Q(currency__icontains=value)
            | Q(name__icontains=value)
            | Q(propagation__icontains=value)
        )

    def is_used_filter(self, queryset, name, value):
        if value is None:
            return queryset
        if value:
            return queryset.filter(Exists(Rate.objects.filter(currency=OuterRef("pk"))))
        else:
            return queryset.filter(
                ~Exists(Rate.objects.filter(currency=OuterRef("pk")))
            )


class RateFilter(filters.FilterSet):
    currency = filters.CharFilter(
        field_name="currency__currency", lookup_expr="icontains", label=_("Currency")
    )
    min_date = filters.DateFilter(
        field_name="date", lookup_expr="gte", label=_("Min date")
    )
    max_date = filters.DateFilter(
        field_name="date", lookup_expr="lte", label=_("Max date")
    )
