from typing import Any
from django.core.management.base import CommandError
from django_tqdm import BaseCommand
from razmga.models import Currency, Rate


class Command(BaseCommand):
    def handle(self, *args: Any, **options: Any) -> str | None:
        updater = "pgi"
        sep = "\t"
        filename = "Rates.csv"
        try:
            with open(filename, "r") as file:
                line_count = len(file.readlines())
        except FileNotFoundError:
            raise CommandError(f"{filename} does not exist.")
        t = self.tqdm(total=line_count)
        with open(filename, "r") as file:
            for line in file:
                t.update(1)
                line = line.replace("\n", "")
                data = line.split(sep)
                date = data[5]
                rate = data[6]
                currency = Currency.objects.get(pk=data[7])
                Rate.objects.create(
                    date=date,
                    rate=rate,
                    currency=currency,
                    created_by=updater,
                    updated_by=updater,
                )
        t.close()
        self.info(self.style.SUCCESS(f"{line_count} lines imported."))
