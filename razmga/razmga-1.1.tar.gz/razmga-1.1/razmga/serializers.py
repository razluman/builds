from rest_framework import serializers
from .raz.serializers import UpdaterSerializer
from .raz.models import UPDATER_FIELDS
from .models import Currency, Rate


class CurrencySerializer(UpdaterSerializer):
    url = serializers.HyperlinkedIdentityField(view_name="currency-api-detail")

    class Meta:
        model = Currency
        fields = ["url"] + model.list_display


class CurrencyRetrieveSerializer(UpdaterSerializer):
    class Meta:
        model = Currency
        fields = model.list_display + UPDATER_FIELDS


class RateSerializer(UpdaterSerializer):
    url = serializers.HyperlinkedIdentityField(view_name="rate-api-detail")

    class Meta:
        model = Rate
        fields = ["url"] + model.list_display


class RateRetrieveSerializer(UpdaterSerializer):
    class Meta:
        model = Rate
        fields = model.list_display + UPDATER_FIELDS
