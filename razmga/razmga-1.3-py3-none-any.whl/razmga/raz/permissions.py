from rest_framework import permissions


class ReadOnlyPermission(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.method in permissions.SAFE_METHODS


class UserBasedPermission(permissions.BasePermission):
    def __init__(self, app, model, anonym_can_view=False) -> None:
        super().__init__()
        self.app = app
        self.model = model
        self.anonym_can_view = anonym_can_view

    def has_permission(self, request, view):
        return self.user_permission(request)

    def user_permission(self, request):
        method = request.method
        user = request.user
        is_authenticated = user and user.is_authenticated
        if self.anonym_can_view and method in permissions.SAFE_METHODS:
            return True
        if not is_authenticated:
            return False
        if method in permissions.SAFE_METHODS:
            if user.has_perm(f"{self.app}.view_{self.model}"):
                return True
        if method == "POST":
            if user.has_perm(f"{self.app}.add_{self.model}"):
                return True
        if method in ["PUT", "PATCH"]:
            if request.user.has_perm(f"{self.app}.change_{self.model}"):
                return True
        if method == "DELETE":
            if request.user.has_perm(f"{self.app}.delete_{self.model}"):
                return True
        return False
