from rest_framework import viewsets

# from knox.auth import TokenAuthentication
from .raz.permissions import ReadOnlyPermission
from .models import Currency, Rate
from .serializers import (
    CurrencySerializer,
    CurrencyRetrieveSerializer,
    RateSerializer,
    RateRetrieveSerializer,
)
from .filters import CurrencyFilter, RateFilter


class CurrencyViewSet(viewsets.ModelViewSet):
    queryset = Currency.objects.all().order_by("currency")
    serializer_class = CurrencySerializer
    # authentication_classes = [TokenAuthentication]
    permission_classes = [ReadOnlyPermission]
    filterset_class = CurrencyFilter

    def get_serializer_class(self):
        if self.action == "retrieve":
            return CurrencyRetrieveSerializer
        return super().get_serializer_class()


class RateViewSet(viewsets.ModelViewSet):
    queryset = Rate.objects.all().order_by("-date", "currency")
    serializer_class = RateSerializer
    # authentication_classes = [TokenAuthentication]
    permission_classes = [ReadOnlyPermission]
    filterset_class = RateFilter

    def get_serializer_class(self):
        if self.action == "retrieve":
            return RateRetrieveSerializer
        return super().get_serializer_class()
