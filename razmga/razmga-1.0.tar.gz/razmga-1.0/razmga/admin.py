from import_export.resources import ModelResource
from import_export.admin import ImportExportMixin, ExportMixin
from django.contrib import admin
from .raz.admin import UpdaterModelAdmin
from .models import Currency, Rate


@admin.register(Currency)
class CurrencyAdmin(ImportExportMixin, UpdaterModelAdmin):
    ordering = ["currency"]
    search_fields = ["currency"]
    my_display = Currency.list_display

    class CurrencyResource(ModelResource):
        def before_import_row(self, row, row_number=None, **kwargs):
            row["created_by"] = kwargs["user"].username
            row["updated_by"] = kwargs["user"].username
            return super().before_import_row(row, row_number, **kwargs)

        class Meta:
            model = Currency
            skip_unchanged = True
            report_skipped = True
            import_id_fields = ["currency"]

    resource_class = CurrencyResource


@admin.register(Rate)
class RateAdmin(ExportMixin, UpdaterModelAdmin):
    ordering = ["-date", "currency"]
    search_fields = ["date", "currency__currency"]
    autocomplete_fields = ["currency"]
    my_display = Rate.list_display
